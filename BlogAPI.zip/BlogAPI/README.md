# blogAPI_Tutorial
This repository contains the source code for  an [aricle](https://chinwendu.medium.com/how-to-build-a-restful-blog-api-with-nodejs-express-and-mongodb-24a889dec33) I wrote that explains how to build a REST API with NodeJS and ExpressJs.
